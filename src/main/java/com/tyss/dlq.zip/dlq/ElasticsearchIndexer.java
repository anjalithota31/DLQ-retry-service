package com.tyss.dlq;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.ElasticsearchStatusException;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.xcontent.XContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Handles indexing documents into Elasticsearch.
 *
 * Two modes:
 *  - Single document : index() / indexAsAllStrings()  — used for failed-docs index
 *  - Batch           : bulkIndex() / bulkIndexAsAllStrings() — used for main poll loop
 */
public class ElasticsearchIndexer {

    private static final Logger log = LoggerFactory.getLogger(ElasticsearchIndexer.class);

    private final RestHighLevelClient client;
    private final ObjectMapper mapper;
    private final int maxRetries;
    private final long initialRetryBackoffMs;
    private final CircuitBreaker circuitBreaker;

    public ElasticsearchIndexer(RestHighLevelClient client, ObjectMapper mapper) {
        this(client, mapper, 3, 100, new CircuitBreaker()); // defaults: 3 retries, 100ms initial backoff
    }

    public ElasticsearchIndexer(RestHighLevelClient client, ObjectMapper mapper, 
                                   int maxRetries, long initialRetryBackoffMs) {
        this(client, mapper, maxRetries, initialRetryBackoffMs, new CircuitBreaker());
    }

    public ElasticsearchIndexer(RestHighLevelClient client, ObjectMapper mapper, 
                                   int maxRetries, long initialRetryBackoffMs, CircuitBreaker circuitBreaker) {
        this.client = client;
        this.mapper = mapper;
        this.maxRetries = maxRetries;
        this.initialRetryBackoffMs = initialRetryBackoffMs;
        this.circuitBreaker = circuitBreaker;
    }

    // -------------------------------------------------------------------------
    // Single-document methods (used for failed-docs index — low volume)
    // -------------------------------------------------------------------------

    public boolean index(String index, String id, Map<String, Object> document) {
        try {
            String json = mapper.writeValueAsString(document);
            IndexRequest request = new IndexRequest(index).id(id).source(json, XContentType.JSON);
            client.index(request, RequestOptions.DEFAULT);
            log.debug("Indexed document. index={}, id={}", index, id);
            return true;
        } catch (Exception e) {
            log.error("Failed to index document. index={}, id={}", index, id, e);
            return false;
        }
    }

    public boolean indexAsAllStrings(String rawIndex, String id,
                                     Map<String, Object> originalDocument,
                                     Map<String, RepairResult.UnconvertibleField> unconvertibleFields) {
        try {
            Map<String, Object> rawDoc = toStringValueMap(originalDocument, unconvertibleFields);
            String json = mapper.writeValueAsString(rawDoc);
            IndexRequest request = new IndexRequest(rawIndex).id(id).source(json, XContentType.JSON);
            client.index(request, RequestOptions.DEFAULT);
            log.debug("Indexed raw-string document. index={}, id={}", rawIndex, id);
            return true;
        } catch (Exception e) {
            log.error("Failed to index raw-string document. index={}, id={}", rawIndex, id, e);
            return false;
        }
    }

    // -------------------------------------------------------------------------
    // Bulk methods (used for main poll loop — high volume)
    // -------------------------------------------------------------------------

    /**
     * Bulk-indexes a list of repaired documents into the target index with retry logic.
     * Returns the list of record keys that FAILED to index (empty = all succeeded).
     */
    public List<String> bulkIndex(String index, List<BulkEntry> entries) {
        List<String> failed = new ArrayList<>();
        if (entries.isEmpty()) return failed;

        BulkRequest bulk = new BulkRequest();
        for (BulkEntry e : entries) {
            try {
                String json = mapper.writeValueAsString(e.document);
                bulk.add(new IndexRequest(index).id(e.id).source(json, XContentType.JSON));
            } catch (Exception ex) {
                log.error("Failed to serialize document for bulk. id={}", e.id, ex);
                failed.add(e.id);
            }
        }

        if (bulk.numberOfActions() == 0) return failed;

        // Check circuit breaker before attempting ES call
        if (circuitBreaker.getState() == CircuitBreaker.State.OPEN) {
            log.error("Circuit breaker is OPEN, marking all {} documents as failed", entries.size());
            entries.forEach(en -> failed.add(en.id));
            return failed;
        }

        // Retry logic with exponential backoff
        int attempt = 0;
        long backoffMs = initialRetryBackoffMs;
        
        while (attempt <= maxRetries) {
            try {
                BulkResponse response = client.bulk(bulk, RequestOptions.DEFAULT);
                List<String> attemptFailed = new ArrayList<>();
                
                for (BulkItemResponse item : response.getItems()) {
                    if (item.isFailed()) {
                        if (isTransientFailure(item.getFailure().getStatus().getStatus())) {
                            // Transient failure - will retry
                            log.warn("Transient failure on attempt {}/{}. index={}, id={}, reason={}",
                                    attempt + 1, maxRetries + 1, index, item.getId(), item.getFailureMessage());
                            attemptFailed.add(item.getId());
                        } else {
                            // Permanent failure - no point retrying
                            log.error("Permanent failure. index={}, id={}, reason={}",
                                    index, item.getId(), item.getFailureMessage());
                            failed.add(item.getId());
                        }
                    }
                }
                
                if (attemptFailed.isEmpty()) {
                    // All succeeded or only permanent failures
                    log.debug("Bulk indexed {} docs into '{}'. failures={}", entries.size(), index, failed.size());
                    circuitBreaker.onSuccess(); // Notify circuit breaker of success
                    return failed;
                }
                
                // Rebuild bulk request with only transiently failed items
                bulk = rebuildBulkRequest(index, entries, attemptFailed);
                failed.addAll(attemptFailed);
                
                if (attempt < maxRetries) {
                    log.info("Retrying {} transiently failed documents after {}ms backoff", 
                            attemptFailed.size(), backoffMs);
                    Thread.sleep(backoffMs);
                    backoffMs = Math.min(backoffMs * 2, 5000); // Cap at 5 seconds
                }
                
                attempt++;
                
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                log.error("Bulk indexing interrupted", ie);
                circuitBreaker.onFailure(); // Notify circuit breaker of failure
                entries.forEach(en -> failed.add(en.id));
                return failed;
            } catch (Exception e) {
                circuitBreaker.onFailure(); // Notify circuit breaker of failure
                if (isTransientException(e) && attempt < maxRetries) {
                    log.warn("Transient exception on attempt {}/{}. Will retry after {}ms: {}",
                            attempt + 1, maxRetries + 1, backoffMs, e.getMessage());
                    try {
                        Thread.sleep(backoffMs);
                        backoffMs = Math.min(backoffMs * 2, 5000);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        entries.forEach(en -> failed.add(en.id));
                        return failed;
                    }
                } else {
                    log.error("Bulk request failed permanently for index={}. Marking all {} as failed.", 
                            index, entries.size(), e);
                    entries.forEach(en -> failed.add(en.id));
                    return failed;
                }
                attempt++;
            }
        }

        return failed;
    }

    /**
     * Bulk-indexes a list of documents into the raw fallback index with ALL field values as strings.
     * Failed IDs are returned (empty = all succeeded). Includes retry logic.
     */
    public List<String> bulkIndexAsAllStrings(String rawIndex, List<RawBulkEntry> entries) {
        List<String> failed = new ArrayList<>();
        if (entries.isEmpty()) return failed;

        BulkRequest bulk = new BulkRequest();
        for (RawBulkEntry e : entries) {
            try {
                Map<String, Object> rawDoc = toStringValueMap(e.originalDocument, e.unconvertibleFields);
                String json = mapper.writeValueAsString(rawDoc);
                bulk.add(new IndexRequest(rawIndex).id(e.id).source(json, XContentType.JSON));
            } catch (Exception ex) {
                log.error("Failed to serialize raw document for bulk. id={}", e.id, ex);
                failed.add(e.id);
            }
        }
        if (bulk.numberOfActions() == 0) return failed;

        // Retry logic with exponential backoff
        int attempt = 0;
        long backoffMs = initialRetryBackoffMs;
        
        while (attempt <= maxRetries) {
            try {
                BulkResponse response = client.bulk(bulk, RequestOptions.DEFAULT);
                List<String> attemptFailed = new ArrayList<>();
                
                for (BulkItemResponse item : response.getItems()) {
                    if (item.isFailed()) {
                        if (isTransientFailure(item.getFailure().getStatus().getStatus())) {
                            log.warn("Transient raw-index failure on attempt {}/{}. index={}, id={}, reason={}",
                                    attempt + 1, maxRetries + 1, rawIndex, item.getId(), item.getFailureMessage());
                            attemptFailed.add(item.getId());
                        } else {
                            log.error("Permanent raw-index failure. index={}, id={}, reason={}",
                                    rawIndex, item.getId(), item.getFailureMessage());
                            failed.add(item.getId());
                        }
                    }
                }
                
                if (attemptFailed.isEmpty()) {
                    log.debug("Bulk indexed {} raw docs into '{}'. failures={}", entries.size(), rawIndex, failed.size());
                    return failed;
                }
                
                bulk = rebuildRawBulkRequest(rawIndex, entries, attemptFailed);
                failed.addAll(attemptFailed);
                
                if (attempt < maxRetries) {
                    log.info("Retrying {} transiently failed raw documents after {}ms backoff", 
                            attemptFailed.size(), backoffMs);
                    Thread.sleep(backoffMs);
                    backoffMs = Math.min(backoffMs * 2, 5000);
                }
                
                attempt++;
                
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                log.error("Bulk raw indexing interrupted", ie);
                entries.forEach(en -> failed.add(en.id));
                return failed;
            } catch (Exception e) {
                if (isTransientException(e) && attempt < maxRetries) {
                    log.warn("Transient exception in raw indexing on attempt {}/{}. Will retry after {}ms: {}",
                            attempt + 1, maxRetries + 1, backoffMs, e.getMessage());
                    try {
                        Thread.sleep(backoffMs);
                        backoffMs = Math.min(backoffMs * 2, 5000);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        entries.forEach(en -> failed.add(en.id));
                        return failed;
                    }
                } else {
                    log.error("Bulk raw request failed permanently for index={}. Marking all {} as failed.", 
                            rawIndex, entries.size(), e);
                    entries.forEach(en -> failed.add(en.id));
                    return failed;
                }
                attempt++;
            }
        }

        return failed;
    }

    // -------------------------------------------------------------------------
    // Entry types for bulk operations
    // -------------------------------------------------------------------------

    public static class BulkEntry {
        public final String id;
        public final Map<String, Object> document;
        public BulkEntry(String id, Map<String, Object> document) {
            this.id = id;
            this.document = document;
        }
    }

    public static class RawBulkEntry {
        public final String id;
        public final Map<String, Object> originalDocument;
        public final Map<String, RepairResult.UnconvertibleField> unconvertibleFields;
        public RawBulkEntry(String id, Map<String, Object> originalDocument,
                            Map<String, RepairResult.UnconvertibleField> unconvertibleFields) {
            this.id = id;
            this.originalDocument = originalDocument;
            this.unconvertibleFields = unconvertibleFields;
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /** Builds a Map where every value is a String, plus a _dlq_failures metadata field. */
    private Map<String, Object> toStringValueMap(Map<String, Object> original,
                                                  Map<String, RepairResult.UnconvertibleField> unconvertible) {
        Map<String, Object> result = new LinkedHashMap<>();

        // All original fields as strings
        for (Map.Entry<String, Object> e : original.entrySet()) {
            Object v = e.getValue();
            result.put(e.getKey(), v == null ? null : toStr(v));
        }

        // Overlay unconvertible fields with their original string values
        for (Map.Entry<String, RepairResult.UnconvertibleField> e : unconvertible.entrySet()) {
            result.put(e.getKey(), e.getValue().getOriginalValue());
        }

        // Embed failure reasons as a nested metadata field so they are queryable in ES
        // Structure: { "_dlq_failures": { "fieldName": { "esType": "...", "reason": "..." } } }
        if (!unconvertible.isEmpty()) {
            Map<String, Object> failures = new LinkedHashMap<>();
            for (Map.Entry<String, RepairResult.UnconvertibleField> e : unconvertible.entrySet()) {
                Map<String, String> detail = new LinkedHashMap<>();
                detail.put("esType", e.getValue().getEsType());
                detail.put("reason", e.getValue().getReason());
                failures.put(e.getKey(), detail);
            }
            result.put("_dlq_failures", failures);
        }

        return result;
    }

    private String toStr(Object value) {
        try {
            return (value instanceof String) ? (String) value : mapper.writeValueAsString(value);
        } catch (Exception e) {
            return String.valueOf(value);
        }
    }

    // -------------------------------------------------------------------------
    // Retry and Error Classification Helpers
    // -------------------------------------------------------------------------

    /**
     * Determines if an HTTP status code represents a transient failure.
     * Transient failures can be retried, permanent failures should not.
     */
    private boolean isTransientFailure(int status) {
        return status == 429 || // Too Many Requests (rate limiting)
               status == 503 || // Service Unavailable
               status == 502 || // Bad Gateway
               status == 504;   // Gateway Timeout
    }

    /**
     * Determines if an exception represents a transient failure.
     */
    private boolean isTransientException(Exception e) {
        if (e instanceof ElasticsearchStatusException) {
            ElasticsearchStatusException ese = (ElasticsearchStatusException) e;
            return isTransientFailure(ese.status().getStatus());
        }
        // Network-related exceptions are typically transient
        String message = e.getMessage().toLowerCase();
        return message != null && (message.contains("connection") || 
               message.contains("timeout") ||
               message.contains("network") ||
               message.contains("unavailable"));
    }

    /**
     * Rebuilds a bulk request with only the failed entries for retry.
     */
    private BulkRequest rebuildBulkRequest(String index, List<BulkEntry> allEntries, List<String> failedIds) {
        BulkRequest newBulk = new BulkRequest();
        for (BulkEntry entry : allEntries) {
            if (failedIds.contains(entry.id)) {
                try {
                    String json = mapper.writeValueAsString(entry.document);
                    newBulk.add(new IndexRequest(index).id(entry.id).source(json, XContentType.JSON));
                } catch (Exception ex) {
                    log.error("Failed to rebuild bulk request for id={}", entry.id, ex);
                }
            }
        }
        return newBulk;
    }

    /**
     * Rebuilds a raw bulk request with only the failed entries for retry.
     */
    private BulkRequest rebuildRawBulkRequest(String index, List<RawBulkEntry> allEntries, List<String> failedIds) {
        BulkRequest newBulk = new BulkRequest();
        for (RawBulkEntry entry : allEntries) {
            if (failedIds.contains(entry.id)) {
                try {
                    Map<String, Object> rawDoc = toStringValueMap(entry.originalDocument, entry.unconvertibleFields);
                    String json = mapper.writeValueAsString(rawDoc);
                    newBulk.add(new IndexRequest(index).id(entry.id).source(json, XContentType.JSON));
                } catch (Exception ex) {
                    log.error("Failed to rebuild raw bulk request for id={}", entry.id, ex);
                }
            }
        }
        return newBulk;
    }
}
