package com.tyss.dlq;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.GetMappingsRequest;
import org.elasticsearch.cluster.metadata.MappingMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * DLQ Repair Service.
 *
 * Flow per poll batch:
 *   1. Repair all records in-memory against the ES mapping
 *   2. Bulk index repaired docs → target index         (1 ES call)
 *   3. Bulk index raw fallback docs → raw index        (1 ES call, only if unconvertible fields exist)
 *   4. Any doc that still fails ES indexing → stored in dlq-failed-documents index for manual review
 *   5. commitAsync()
 *
 * No retry topic — schema failures are deterministic and won't self-heal on retry.
 * Transient ES failures are handled by the bulk retry built into the ES client.
 */
public class DlqRepairApplication {

    private static final Logger log = LoggerFactory.getLogger(DlqRepairApplication.class);

    public static void main(String[] args) throws Exception {
        log.info("Starting DLQ Repair Service");

        Properties appConfig = loadConfig();
        
        // Validate configuration before starting
        try {
            ConfigValidator.validate(appConfig);
        } catch (IllegalArgumentException e) {
            log.error("Configuration validation failed: {}", e.getMessage());
            System.exit(1);
        }

        // Helper method to get config from env var or properties file
        java.util.function.Function<String, String> getConfig = (key) -> {
            // Convert property key to env var name (e.g., kafka.bootstrap.servers -> KAFKA_BOOTSTRAP_SERVERS)
            String envVarName = key.toUpperCase().replace('.', '_');
            String envValue = System.getenv(envVarName);
            if (envValue != null && !envValue.isEmpty()) {
                return envValue;
            }
            return appConfig.getProperty(key);
        };

        String dlqTopicPattern  = getConfig.apply("dlq.topic.pattern");
        String dlqTopic         = getConfig.apply("dlq.topic");
        String failedIndex      = getConfig.apply("failed.docs.index");
        final String finalFailedIndex = (failedIndex == null) ? "dlq-failed-documents" : failedIndex;
        String esUrl            = getConfig.apply("elasticsearch.url");
        final String finalEsUrl = (esUrl == null) ? "http://localhost:9200" : esUrl;
        String targetIndex      = getConfig.apply("target.index");
        String rawIndex         = getConfig.apply("raw.fallback.index");
        final String finalRawIndex = (rawIndex == null && targetIndex != null) ? targetIndex + "-raw" : rawIndex;
        long   mappingRefreshMs = Long.parseLong(
                getConfig.apply("mapping.refresh.interval.ms"));
        if (mappingRefreshMs == 0) mappingRefreshMs = 300000;
        
        // Mapping cache configuration
        int mappingCacheSize = Integer.parseInt(
                getConfig.apply("mapping.cache.size"));
        if (mappingCacheSize == 0) mappingCacheSize = 100;
        long mappingCacheTtlMinutes = Long.parseLong(
                getConfig.apply("mapping.cache.ttl.minutes"));
        if (mappingCacheTtlMinutes == 0) mappingCacheTtlMinutes = 5;
        
        // Thread pool configuration
        int threadPoolSize = Integer.parseInt(
                getConfig.apply("thread.pool.size"));
        if (threadPoolSize == 0) threadPoolSize = 10;
        int threadPoolQueueSize = Integer.parseInt(
                getConfig.apply("thread.pool.queue.size"));
        if (threadPoolQueueSize == 0) threadPoolQueueSize = 1000;
        
        // Retry configuration
        int maxRetries = Integer.parseInt(getConfig.apply("max.retries"));
        if (maxRetries == 0) maxRetries = 3;
        long retryBackoffMs = Long.parseLong(getConfig.apply("retry.backoff.ms"));
        if (retryBackoffMs == 0) retryBackoffMs = 100;
        
        // Circuit breaker configuration
        int circuitBreakerThreshold = Integer.parseInt(
                getConfig.apply("circuit.breaker.failure.threshold"));
        if (circuitBreakerThreshold == 0) circuitBreakerThreshold = 5;
        long circuitBreakerTimeoutMs = Long.parseLong(
                getConfig.apply("circuit.breaker.timeout.ms"));
        if (circuitBreakerTimeoutMs == 0) circuitBreakerTimeoutMs = 60000;
        
        // Health check configuration
        int healthCheckPort = Integer.parseInt(getConfig.apply("health.check.port"));
        if (healthCheckPort == 0) healthCheckPort = 8080;
        HealthCheckServer healthCheckServer = new HealthCheckServer(healthCheckPort);
        
        // Rate limiter configuration (optional, 0 means disabled)
        double maxRecordsPerSecond = Double.parseDouble(
                getConfig.apply("rate.limit.records.per.second"));
        if (maxRecordsPerSecond == 0) maxRecordsPerSecond = 0;
        RateLimiter rateLimiter = maxRecordsPerSecond > 0 ? new RateLimiter(maxRecordsPerSecond) : null;
        
        try {
            healthCheckServer.start();
        } catch (IOException e) {
            log.warn("Failed to start health check server on port {}", healthCheckPort, e);
        }

        // Credentials: prefer environment variables, fall back to properties file
        String esUser = System.getenv("ES_USERNAME");
        if (esUser == null) esUser = getConfig.apply("elasticsearch.username");
        if (esUser == null) esUser = "";
        String esPass = System.getenv("ES_PASSWORD");
        if (esPass == null) esPass = getConfig.apply("elasticsearch.password");
        if (esPass == null) esPass = "";
        boolean sslVerify = Boolean.parseBoolean(
                getConfig.apply("elasticsearch.ssl.verify"));
        if (getConfig.apply("elasticsearch.ssl.verify") == null) sslVerify = true;

        RestHighLevelClient esClient = buildEsClient(finalEsUrl, esUser, esPass, sslVerify);
        log.info("Elasticsearch client built. url={}, auth={}, sslVerify={}",
                finalEsUrl, !esUser.isEmpty(), sslVerify);

        ObjectMapper mapper = new ObjectMapper();

        // Initialize mapping cache for dynamic multi-index support
        MappingCache mappingCache = new MappingCache(esClient, mappingCacheSize, mappingCacheTtlMinutes);
        log.info("Mapping cache initialized with size={}, ttl={} minutes", mappingCacheSize, mappingCacheTtlMinutes);
        
        // Load initial mapping for backward compatibility
        Map<String, Object> initialMapping = mappingCache.getMapping(targetIndex);
        AtomicReference<Map<String, Object>> mappingRef =
                new AtomicReference<>(initialMapping);
        log.info("Loaded ES mapping for index '{}': {} fields", targetIndex, initialMapping.size());

        // Create circuit breaker and indexer with retry configuration
        CircuitBreaker circuitBreaker = new CircuitBreaker(circuitBreakerThreshold, circuitBreakerTimeoutMs);
        ElasticsearchIndexer indexer = new ElasticsearchIndexer(esClient, mapper, maxRetries, retryBackoffMs, circuitBreaker);
        
        // Create metrics collector
        MetricsCollector metrics = new MetricsCollector();
        
        // Update health check with circuit breaker status
        healthCheckServer.setHealthMessage("Service initialized, circuit breaker: " + circuitBreaker.getState());
        
        KafkaConsumer<String, String> consumer = buildConsumer(appConfig);

        // Subscribe to topics based on configuration
        if (dlqTopicPattern != null && !dlqTopicPattern.isEmpty()) {
            // Use regex pattern to discover and subscribe to matching topics
            List<String> matchedTopics = discoverDlqTopics(consumer, dlqTopicPattern);
            if (!matchedTopics.isEmpty()) {
                consumer.subscribe(matchedTopics);
                log.info("Subscribed to {} DLQ topics matching pattern '{}': {}", 
                        matchedTopics.size(), dlqTopicPattern, matchedTopics);
            } else {
                log.warn("No topics found matching pattern '{}'. Falling back to single topic: {}", 
                        dlqTopicPattern, dlqTopic);
                consumer.subscribe(Collections.singletonList(dlqTopic));
                log.info("Subscribed to DLQ topic: {}", dlqTopic);
            }
        } else {
            // Use single topic (backward compatibility)
            consumer.subscribe(Collections.singletonList(dlqTopic));
            log.info("Subscribed to DLQ topic: {}", dlqTopic);
        }

        // Initialize thread pool for concurrent processing
        ExecutorService threadPool = new ThreadPoolExecutor(
                threadPoolSize,
                threadPoolSize,
                60L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(threadPoolQueueSize),
                new ThreadPoolExecutor.CallerRunsPolicy());
        log.info("Thread pool initialized with size={}, queueSize={}", threadPoolSize, threadPoolQueueSize);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("Shutdown signal received. Flushing and closing.");
            log.info("Final metrics: {}", metrics.getMetricsSummary());
            log.info("Final mapping cache stats: {}", mappingCache.getStats());
            healthCheckServer.setHealthy(false);
            healthCheckServer.setHealthMessage("Shutting down");
            try { consumer.commitSync(); } catch (Exception ignored) {}
            consumer.close();
            threadPool.shutdown();
            try {
                esClient.close();
            } catch (IOException e) {
                log.warn("Error closing ES client", e);
            }
            healthCheckServer.stop();
        }));

        long lastMappingRefresh = System.currentTimeMillis();

        while (true) {

            // ----------------------------------------------------------------
            // Periodic mapping refresh and health check update
            // ----------------------------------------------------------------
            if (System.currentTimeMillis() - lastMappingRefresh >= mappingRefreshMs) {
                try {
                    // Refresh the primary target index mapping
                    Map<String, Object> fresh = mappingCache.getMapping(targetIndex);
                    mappingRef.set(fresh);
                    lastMappingRefresh = System.currentTimeMillis();
                    log.info("Refreshed ES mapping for index '{}': {} fields", targetIndex, fresh.size());
                    
                    // Update health check status
                    healthCheckServer.setHealthy(circuitBreaker.getState() != CircuitBreaker.State.OPEN);
                    healthCheckServer.setHealthMessage(String.format("Operating normally. Circuit breaker: %s, Failures: %d. Cache: %s. %s", 
                            circuitBreaker.getState(), circuitBreaker.getFailureCount(), mappingCache.getStats(), metrics.getMetricsSummary()));
                } catch (Exception e) {
                    log.warn("Failed to refresh ES mapping. Continuing with cached mapping.", e);
                    healthCheckServer.setHealthMessage("Mapping refresh failed: " + e.getMessage());
                }
            }

            // ----------------------------------------------------------------
            // Poll
            // ----------------------------------------------------------------
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(500));
            if (records.isEmpty()) continue;

            log.info("Polled {} records from DLQ topic.", records.count());
            
            // Apply rate limiting if configured
            if (rateLimiter != null) {
                try {
                    rateLimiter.acquire(records.count());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    log.warn("Rate limiting interrupted", e);
                    break;
                }
            }
            
            long batchStartTime = System.currentTimeMillis();
            metrics.incrementRecordsProcessed();

            DocumentRepairer repairer = new DocumentRepairer(mappingRef.get(), mapper);

            // ----------------------------------------------------------------
            // Phase 1: Repair all records in-memory
            // ----------------------------------------------------------------
            List<ElasticsearchIndexer.BulkEntry>    targetBatch = new ArrayList<>();
            List<ElasticsearchIndexer.RawBulkEntry> rawBatch    = new ArrayList<>();
            Map<String, PendingRecord>              pendingById = new LinkedHashMap<>();

            // Group records by target index for efficient bulk operations
            Map<String, List<ConsumerRecord<String, String>>> recordsByIndex = new HashMap<>();
            for (ConsumerRecord<String, String> record : records) {
                String recordTargetIndex = extractTargetIndex(record);
                recordsByIndex.computeIfAbsent(recordTargetIndex, k -> new ArrayList<>()).add(record);
            }
            
            log.info("Processing {} records across {} target indices", records.count(), recordsByIndex.size());
            
            // Process each index group concurrently
            List<Future<Void>> futures = new ArrayList<>();
            for (Map.Entry<String, List<ConsumerRecord<String, String>>> entry : recordsByIndex.entrySet()) {
                String indexTarget = entry.getKey();
                List<ConsumerRecord<String, String>> indexRecords = entry.getValue();
                
                futures.add(threadPool.submit(() -> {
                    try {
                        processIndexBatch(indexTarget, indexRecords, mapper, mappingCache, 
                                repairer, indexer, finalFailedIndex, metrics, finalRawIndex);
                    } catch (Exception e) {
                        log.error("Error processing batch for index '{}'", indexTarget, e);
                        throw new RuntimeException(e);
                    }
                    return null;
                }));
            }
            
            // Wait for all batches to complete
            for (Future<Void> future : futures) {
                try {
                    future.get(5, TimeUnit.MINUTES);
                } catch (TimeoutException e) {
                    log.error("Timeout waiting for batch processing");
                } catch (Exception e) {
                    log.error("Error in batch processing", e);
                }
            }

            // ----------------------------------------------------------------
            // Phase 5: Commit offsets
            // ----------------------------------------------------------------
            consumer.commitAsync((offsets, exception) -> {
                if (exception != null) {
                    log.warn("Async offset commit failed. Will retry on next poll.", exception);
                }
            });
            
            // Record batch processing time
            long processingTime = System.currentTimeMillis() - batchStartTime;
            metrics.recordProcessingTime(processingTime);
            log.debug("Batch processing completed in {}ms", processingTime);
        }
    }

    // -------------------------------------------------------------------------
    // Failed-doc storage helpers
    // -------------------------------------------------------------------------

    /** Called when the document was repaired but ES still rejected it. */
    private static void storeIndexFailure(ConsumerRecord<String, String> record,
                                           RepairResult repairResult,
                                           ElasticsearchIndexer indexer,
                                           String failedIndex,
                                           ObjectMapper mapper) {
        try {
            FailedDocument failedDoc = new FailedDocument(
                    record.key(),
                    repairResult.getDocument(),
                    repairResult.getRepairedFields(),
                    repairResult.getRemovedFields(),
                    "ES rejected document after repair");
            indexer.index(failedIndex, record.key(), mapper.convertValue(failedDoc, Map.class));
        } catch (Exception e) {
            log.error("Could not store index-failure doc. id={}. Record may be lost.", record.key(), e);
        }
    }

    /** Called when the record could not be parsed or repaired at all. */
    private static void storeParseFailure(ConsumerRecord<String, String> record,
                                           Exception cause,
                                           ElasticsearchIndexer indexer,
                                           String failedIndex,
                                           ObjectMapper mapper) {
        try {
            // Store the raw string value so nothing is lost
            Map<String, Object> rawPayload = new LinkedHashMap<>();
            rawPayload.put("rawValue", record.value());
            FailedDocument failedDoc = new FailedDocument(
                    record.key(),
                    rawPayload,
                    Collections.emptyList(),
                    Collections.emptyList(),
                    "Parse/repair error: " + cause.getMessage());
            indexer.index(failedIndex, record.key(), mapper.convertValue(failedDoc, Map.class));
        } catch (Exception e) {
            log.error("Could not store parse-failure doc. id={}. Record may be lost.", record.key(), e);
        }
    }

    /**
     * Extracts the target index from the record headers or derives it from the topic name.
     */
    private static String extractTargetIndex(ConsumerRecord<String, String> record) {
        // First, try to extract from headers
        Headers headers = record.headers();
        for (Header header : headers) {
            if (header.key().equals("X-Target-Index")) {
                String index = new String(header.value(), StandardCharsets.UTF_8);
                log.debug("Extracted target index from header: {}", index);
                return index;
            }
        }
        
        // Fallback: derive from topic name
        String topic = record.topic();
        String index = topic.replace("-dlq", "");
        log.debug("Derived target index from topic '{}': {}", topic, index);
        return index;
    }
    
    /**
     * Processes a batch of records for a specific target index.
     */
    private static void processIndexBatch(String targetIndex, 
                                   List<ConsumerRecord<String, String>> records,
                                   ObjectMapper mapper,
                                   MappingCache mappingCache,
                                   DocumentRepairer repairer,
                                   ElasticsearchIndexer indexer,
                                   String failedIndex,
                                   MetricsCollector metrics,
                                   String rawIndex) {
        
        // Get mapping for this index
        Map<String, Object> mapping = mappingCache.getMapping(targetIndex);
        DocumentRepairer indexRepairer = new DocumentRepairer(mapping, mapper);
        
        List<ElasticsearchIndexer.BulkEntry> targetBatch = new ArrayList<>();
        List<ElasticsearchIndexer.RawBulkEntry> rawBatch = new ArrayList<>();
        Map<String, PendingRecord> pendingById = new LinkedHashMap<>();
        
        // Phase 1: Repair all records in-memory
        for (ConsumerRecord<String, String> record : records) {
            try {
                @SuppressWarnings("unchecked")
                Map<String, Object> originalDoc = mapper.readValue(record.value(), Map.class);

                RepairResult result = indexRepairer.repair(originalDoc);

                log.debug("Repaired record. id={}, repaired={}, removed={}, unconvertible={}",
                        record.key(),
                        result.getRepairedFields().size(),
                        result.getRemovedFields().size(),
                        result.getUnconvertibleFields().size());

                if (!result.getRepairedFields().isEmpty()) {
                    metrics.incrementRecordsRepaired();
                }
                
                if (!result.getUnconvertibleFields().isEmpty()) {
                    metrics.incrementRecordsWithUnconvertibleFields();
                }

                targetBatch.add(new ElasticsearchIndexer.BulkEntry(
                        record.key(), result.getDocument()));

                if (!result.getUnconvertibleFields().isEmpty()) {
                    rawBatch.add(new ElasticsearchIndexer.RawBulkEntry(
                            record.key(), originalDoc, result.getUnconvertibleFields()));
                }

                pendingById.put(record.key(), new PendingRecord(record, result));

            } catch (Exception e) {
                // Malformed JSON or unexpected repair crash — store directly in failed-docs
                log.error("Failed to parse/repair DLQ record. offset={}. Storing in failed-docs index.",
                        record.offset(), e);
                storeParseFailure(record, e, indexer, failedIndex, mapper);
            }
        }
        
        // Phase 2: Bulk index repaired docs → target index
        List<String> failedIds = indexer.bulkIndex(targetIndex, targetBatch);
        Set<String> failedSet = new HashSet<>(failedIds);

        metrics.incrementEsBulkOperations();
        metrics.incrementRecordsSucceeded(targetBatch.size() - failedSet.size());
        metrics.incrementRecordsFailed(failedSet.size());

        log.info("Bulk index complete for index '{}'. total={}, succeeded={}, failed={}",
                targetIndex, targetBatch.size(), targetBatch.size() - failedSet.size(), failedSet.size());

        // Phase 3: Bulk index raw fallback docs → raw index
        String indexRawIndex = rawIndex.equals(targetIndex + "-raw") ? targetIndex + "-raw" : rawIndex;
        if (!rawBatch.isEmpty()) {
            List<ElasticsearchIndexer.RawBulkEntry> rawToIndex = new ArrayList<>();
            for (ElasticsearchIndexer.RawBulkEntry e : rawBatch) {
                if (!failedSet.contains(e.id)) rawToIndex.add(e);
            }
            if (!rawToIndex.isEmpty()) {
                indexer.bulkIndexAsAllStrings(indexRawIndex, rawToIndex);
                log.info("Bulk raw-index complete for index '{}'. count={}", indexRawIndex, rawToIndex.size());
            }
        }

        // Phase 4: Store permanently failed docs in dlq-failed-documents
        for (String failedId : failedIds) {
            PendingRecord pending = pendingById.get(failedId);
            if (pending == null) continue;
            log.error("ES indexing failed after repair. Storing in failed-docs index. id={}", failedId);
            storeIndexFailure(pending.record, pending.repairResult, indexer, failedIndex, mapper);
        }
    }
    
    /**
     * Discovers DLQ topics matching the given regex pattern.
     */
    private static List<String> discoverDlqTopics(KafkaConsumer<String, String> consumer, String pattern) {
        try {
            Pattern regex = Pattern.compile(pattern);
            return consumer.listTopics().keySet().stream()
                    .filter(topic -> regex.matcher(topic).matches())
                    .sorted()
                    .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("Failed to discover topics matching pattern '{}'", pattern, e);
            return Collections.emptyList();
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private static class PendingRecord {
        final ConsumerRecord<String, String> record;
        final RepairResult                   repairResult;

        PendingRecord(ConsumerRecord<String, String> record, RepairResult repairResult) {
            this.record       = record;
            this.repairResult = repairResult;
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> loadMapping(RestHighLevelClient client,
                                                    String index) throws IOException {
        GetMappingsRequest request = new GetMappingsRequest().indices(index);
        MappingMetadata mapping = client.indices()
                .getMapping(request, RequestOptions.DEFAULT)
                .mappings()
                .get(index);
        if (mapping == null) {
            log.warn("No mapping found for index '{}'. Repair will skip field validation.", index);
            return Collections.emptyMap();
        }
        Map<String, Object> source = mapping.sourceAsMap();
        Object props = source.get("properties");
        return props instanceof Map ? (Map<String, Object>) props : Collections.emptyMap();
    }

    private static Properties loadConfig() throws IOException {
        Properties props = new Properties();
        try (InputStream is = DlqRepairApplication.class
                .getClassLoader().getResourceAsStream("dlq-repair.properties")) {
            if (is == null)
                throw new IllegalStateException("dlq-repair.properties not found on classpath");
            props.load(is);
        }
        return props;
    }

    private static RestHighLevelClient buildEsClient(String esUrl, String username, String password,
                                                      boolean sslVerify) {
        RestClientBuilder builder = RestClient.builder(HttpHost.create(esUrl));
        boolean hasAuth = username != null && !username.isEmpty();
        boolean isHttps = esUrl.toLowerCase().startsWith("https");

        if (hasAuth || (isHttps && !sslVerify)) {
            builder.setHttpClientConfigCallback(httpClientBuilder -> {
                if (hasAuth) {
                    BasicCredentialsProvider credProv = new BasicCredentialsProvider();
                    credProv.setCredentials(AuthScope.ANY,
                            new UsernamePasswordCredentials(username, password));
                    httpClientBuilder.setDefaultCredentialsProvider(credProv);
                    log.info("Elasticsearch authentication enabled for user '{}'.", username);
                }
                if (isHttps && !sslVerify) {
                    try {
                        httpClientBuilder
                                .setSSLContext(new SSLContextBuilder()
                                        .loadTrustMaterial(null, TrustAllStrategy.INSTANCE).build())
                                .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE);
                        log.warn("SSL certificate verification disabled (elasticsearch.ssl.verify=false). "
                                + "Do NOT use this in production with public-facing clusters.");
                    } catch (Exception e) {
                        throw new IllegalStateException("Failed to build SSL context", e);
                    }
                }
                return httpClientBuilder;
            });
        }
        return new RestHighLevelClient(builder);
    }

    private static KafkaConsumer<String, String> buildConsumer(Properties appConfig) {
        Properties props = new Properties();
        
        // Helper to get config from env var or properties file
        java.util.function.Function<String, String> getConfig = (key) -> {
            String envVarName = key.toUpperCase().replace('.', '_');
            String envValue = System.getenv(envVarName);
            if (envValue != null && !envValue.isEmpty()) {
                return envValue;
            }
            return appConfig.getProperty(key);
        };
        
        // Prefer environment variables for sensitive Kafka config
        String bootstrapServers = getConfig.apply("kafka.bootstrap.servers");
        if (bootstrapServers == null) bootstrapServers = "localhost:9092";
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        
        String groupId = getConfig.apply("kafka.consumer.group.id");
        if (groupId == null) groupId = "dlq-repair-service";
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringDeserializer");
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringDeserializer");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,  "earliest");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        
        String maxPollRecords = getConfig.apply("consumer.max.poll.records");
        if (maxPollRecords == null) maxPollRecords = "500";
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxPollRecords);
        
        // Prevent rebalance if bulk ES indexing takes longer than default 5 min
        String maxPollInterval = getConfig.apply("consumer.max.poll.interval.ms");
        if (maxPollInterval == null) maxPollInterval = "600000";
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPollInterval);
        
        return new KafkaConsumer<>(props);
    }
}
