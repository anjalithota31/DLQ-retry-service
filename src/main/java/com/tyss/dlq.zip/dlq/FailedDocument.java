package com.tyss.dlq;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Document stored in the failed-documents index when max retries are exhausted.
 * Contains the full document, repair history, and failure reason for manual review.
 */
public class FailedDocument {

    private final String              documentId;
    private final Map<String, Object> document;
    private final List<RepairAction>  repairedFields;
    private final List<RemovedField>  removedFields;
    private final String              failureReason;
    private final String              failedAt;

    public FailedDocument(String documentId,
                          Map<String, Object> document,
                          List<RepairAction> repairedFields,
                          List<RemovedField> removedFields,
                          String failureReason) {
        this.documentId     = documentId;
        this.document       = document;
        this.repairedFields = repairedFields;
        this.removedFields  = removedFields;
        this.failureReason  = failureReason;
        this.failedAt       = Instant.now().toString();
    }

    public String              getDocumentId()    { return documentId; }
    public Map<String, Object> getDocument()      { return document; }
    public List<RepairAction>  getRepairedFields(){ return repairedFields; }
    public List<RemovedField>  getRemovedFields() { return removedFields; }
    public String              getFailureReason() { return failureReason; }
    public String              getFailedAt()      { return failedAt; }
}
