package com.tyss.dlq;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.GetMappingsRequest;
import org.elasticsearch.cluster.metadata.MappingMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Caching layer for Elasticsearch index mappings.
 * Dynamically loads and caches mappings for multiple indices.
 */
public class MappingCache {

    private static final Logger log = LoggerFactory.getLogger(MappingCache.class);

    private final RestHighLevelClient esClient;
    private final Cache<String, Map<String, Object>> cache;

    /**
     * Creates a new mapping cache with the specified configuration.
     *
     * @param esClient Elasticsearch client
     * @param maxSize Maximum number of mappings to cache
     * @param ttlMinutes Time-to-live for cached mappings in minutes
     */
    public MappingCache(RestHighLevelClient esClient, int maxSize, long ttlMinutes) {
        this.esClient = esClient;
        this.cache = Caffeine.newBuilder()
                .maximumSize(maxSize)
                .expireAfterWrite(ttlMinutes, TimeUnit.MINUTES)
                .refreshAfterWrite(ttlMinutes / 2, TimeUnit.MINUTES)
                .build(this::loadMapping);
        log.info("MappingCache initialized with maxSize={}, ttlMinutes={}", maxSize, ttlMinutes);
    }

    /**
     * Gets the mapping for the specified index.
     * Returns cached mapping if available, otherwise loads from Elasticsearch.
     *
     * @param index The Elasticsearch index name
     * @return Map of field names to their mapping definitions
     */
    public Map<String, Object> getMapping(String index) {
        try {
            return cache.get(index, this::loadMapping);
        } catch (Exception e) {
            log.warn("Failed to get mapping for index '{}', returning empty map", index, e);
            return Collections.emptyMap();
        }
    }

    /**
     * Loads the mapping for the specified index from Elasticsearch.
     * This is called automatically by the cache when a mapping is not cached.
     *
     * @param index The Elasticsearch index name
     * @return Map of field names to their mapping definitions
     */
    private Map<String, Object> loadMapping(String index) {
        try {
            GetMappingsRequest request = new GetMappingsRequest().indices(index);
            MappingMetadata mapping = esClient.indices()
                    .getMapping(request, RequestOptions.DEFAULT)
                    .mappings()
                    .get(index);
            
            if (mapping == null) {
                log.warn("No mapping found for index '{}'. Repair will skip field validation.", index);
                return Collections.emptyMap();
            }
            
            Map<String, Object> source = mapping.sourceAsMap();
            Object props = source.get("properties");
            Map<String, Object> properties = props instanceof Map ? (Map<String, Object>) props : Collections.emptyMap();
            
            log.info("Loaded ES mapping for index '{}': {} fields", index, properties.size());
            return properties;
            
        } catch (IOException e) {
            log.error("Failed to load mapping for index '{}'", index, e);
            return Collections.emptyMap();
        }
    }

    /**
     * Invalidates the cached mapping for the specified index.
     * Useful when you know the mapping has changed and want to force a reload.
     *
     * @param index The Elasticsearch index name
     */
    public void invalidate(String index) {
        cache.invalidate(index);
        log.info("Invalidated cache for index '{}'", index);
    }

    /**
     * Invalidates all cached mappings.
     */
    public void invalidateAll() {
        cache.invalidateAll();
        log.info("Invalidated all cached mappings");
    }

    /**
     * Returns cache statistics for monitoring.
     *
     * @return Cache statistics as a string
     */
    public String getStats() {
        com.github.benmanes.caffeine.cache.stats.CacheStats stats = cache.stats();
        return String.format("CacheStats{hitRate=%.2f%%, hitCount=%d, missCount=%d, loadSuccessCount=%d, loadFailureCount=%d, totalLoadTime=%dms}",
                stats.hitRate() * 100,
                stats.hitCount(),
                stats.missCount(),
                stats.loadSuccessCount(),
                stats.loadFailureCount(),
                stats.totalLoadTime() / 1_000_000);
    }
}
